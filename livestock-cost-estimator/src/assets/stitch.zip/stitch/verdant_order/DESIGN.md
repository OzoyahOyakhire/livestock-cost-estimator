# Design System Strategy: The Conversational Concierge

## 1. Overview & Creative North Star
The "Creative North Star" for this design system is **The Digital Curator**. 

In the world of high-velocity food logistics and WhatsApp-based commerce, we must move beyond the "grid of boxes" typical of generic SaaS. We aim for an experience that feels as fluid as a conversation but as structured as a Michelin-star menu. This system breaks the "template" look through **Intentional Asymmetry**—using generous, off-balance white space to draw the eye to critical CTAs—and **Tonal Layering**, where depth is communicated through light and air rather than lines and boxes. The result is a UI that feels "quietly powerful"—efficient enough for a busy restaurateur, yet premium enough for a high-end consumer.

---

### 2. Colors: The Tonal Spectrum
We utilize a sophisticated palette where the 'WhatsApp Green' is treated as a surgical tool—used sparingly to command attention—while the neutrals do the heavy lifting of establishing trust.

*   **Primary Action (`primary` #006d2f / `primary_container` #25D366):** Use the vibrant `#25D366` for active states and critical success paths. The deeper `#006d2f` provides the necessary contrast for text-on-green accessibility.
*   **The Neutral Core:** Our "Crisp White" is represented by `surface_container_lowest` (#ffffff), while the "Deep Charcoal" for text is driven by `on_surface` (#1c1b1b).

#### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to section off major areas of the UI. Structure must be defined by background shifts. To separate a sidebar from a main feed, transition from `surface` (#fcf9f8) to `surface_container_low` (#f6f3f2). Lines create visual "noise"; tonal shifts create "breathing room."

#### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine stationery:
1.  **Base Layer:** `surface` (#fcf9f8) - The desk.
2.  **Section Layer:** `surface_container_low` (#f6f3f2) - The folder.
3.  **Component Layer:** `surface_container_lowest` (#ffffff) - The card or sheet of paper.
By nesting a white card on a light gray section, you create a "natural lift" that feels more premium than a bordered box.

#### The "Glass & Gradient" Rule
To elevate the "WhatsApp Green" from a flat brand color to a premium asset, use a subtle linear gradient on primary buttons: `primary_container` (#25d366) to `primary` (#006d2f) at a 150° angle. For floating navigation or headers, apply a `surface_container_lowest` fill at 80% opacity with a `backdrop-blur` of 20px to achieve a high-end glassmorphism effect.

---

### 3. Typography: Editorial Authority
The hierarchy is built on the interplay between the functional **Inter** and the charismatic **Manrope**.

*   **Display & Headlines (Manrope):** These are your "Editorial" moments. Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) for hero moments. This font carries the "Premium SaaS" weight.
*   **Body & Labels (Inter):** This is your "Utility" engine. `body-md` (0.875rem) is the workhorse for chat logs and order details. 
*   **The Hierarchy of Trust:** Use `title-lg` (Inter, 1.375rem) for card titles. The transition from a Manrope headline to an Inter body creates a "New York Times meets Stripe" aesthetic—authoritative yet deeply functional.

---

### 4. Elevation & Depth: Tonal Layering
We do not use shadows to show "height"; we use them to show "focus."

*   **The Layering Principle:** Depth is achieved by stacking. A `surface_container_highest` (#e5e2e1) element represents a "pressed" or "background" state, while `surface_container_lowest` (#ffffff) represents the most interactive, elevated content.
*   **Ambient Shadows:** When a card must float (e.g., a "New Order" toast), use a multi-layered shadow: 
    *   `box-shadow: 0 4px 6px -1px rgba(28, 27, 27, 0.04), 0 10px 15px -3px rgba(28, 27, 27, 0.08);`
    *   The shadow is never black; it is a diluted version of `on_surface`.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility (e.g., in a high-density data table), use `outline_variant` (#bbcbb9) at **20% opacity**. It should be felt, not seen.

---

### 5. Components: Functional Elegance

#### Buttons
*   **Primary:** High-contrast `primary_container` (#25D366). Roundedness: `lg` (1rem). No border.
*   **Tertiary/Ghost:** No background. Text in `primary`. Use for "Cancel" or "Back" actions. 
*   **Interaction:** On hover, shift background to `primary_fixed_dim` (#3de273).

#### Cards & Lists
*   **Cards:** Use `surface_container_lowest` (#ffffff) with roundedness `xl` (1.5rem). 
*   **Anti-Divider Rule:** Forbid the use of horizontal rules (`<hr>`) in lists. Instead, use `spacing-4` (1rem) of vertical whitespace or a subtle background hover state using `surface_container_high` (#ebe7e7).

#### Input Fields
*   **Style:** Minimalist. No bottom line. Use a `surface_container_low` fill with `rounded-md` (0.75rem). 
*   **Focus State:** A 2px "Ghost Border" using `primary` at 40% opacity.

#### Conversation Chips
*   **Context:** Unique to this platform. Use `secondary_container` (#aaf0b1) for "Customer" messages and `surface_container_highest` for "System" notes. This keeps the WhatsApp-DNA visible but refined.

---

### 6. Do's and Don'ts

**Do:**
*   **Do** use asymmetrical padding (e.g., `px-8 py-12`) to create an editorial feel in headers.
*   **Do** use `primary` green for micro-interactions (loaders, checkmarks, toggles).
*   **Do** leverage "Surface Dim" (#dcd9d9) for disabled states to maintain the sophisticated tonal palette.

**Don't:**
*   **Don't** use 100% black (#000000). Always use `on_surface` (#1c1b1b) for depth.
*   **Don't** use "Default" 4px rounded corners. This system lives in the `lg` (16px) and `xl` (24px) range to feel modern and friendly.
*   **Don't** use standard "drop shadows." If it doesn't look like ambient light hitting a piece of paper, it's too heavy.